"""
Specialized Agents module for The Golden Hand Learning Platform.

This module provides subject-specific intelligent agents that enhance the learning
experience by offering personalized learning paths, content generation, and
performance analysis.
"""
